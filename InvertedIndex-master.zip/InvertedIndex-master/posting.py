class posting:
    def __init__(self,docID,occurence,importance):
        self.docID = docID
        self.occurence = occurence
        self.importance = importance
        